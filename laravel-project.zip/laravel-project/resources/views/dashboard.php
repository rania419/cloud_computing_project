<html>

<head>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/app.js"></script>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"> </script>

</head>
<body>

  <div class="page">
    <nav class="navbar-vertical">
      <ul class="nav flex-column">
          <li class="nav-item">
              <a class="nav-link" href="/dashboard">Dashboard</a>
          </li>
          <li class="nav-item">
          <a class="nav-link" href="create">Create new</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="/">Logout</a>
          </li>
          
      </ul>
  </nav>   

  <div class="btn1">
    <button class="button1" id="container" onclick="myfunction2(this.id)" style="margin-top:30px;">conteneur</button>
    <button class="button1" id="server"onclick="myfunction2(this.id)">serveur</button>
  </div>

  <div class="content">
      
    <div id="right_side_container" style=" height:80vh;overflow:auto;">
      <table id="display_json_data" class="table" style="width: 900px;margin-top:5%;">
        <script>
        window.onload = function() {
          // Call the function from the external file
          myfunction2("container");
        };
        </script></table>
    </div>
    
  </div>
  </div>

  
</body>
</html>




   
