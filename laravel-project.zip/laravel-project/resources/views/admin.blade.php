<html>

<head>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/app.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"> </script>

</head>
<body>

  <div class="page">
    <div class="left_side">
      <ul>
        <li><a href="/">Home</a></li>
        <li><a href="login">login</a></li> 
      </ul>
    </div>

    
    

    <div class="btn1">
      <button class=" button1" id="container" onclick="myfunction2(this.id)" style="margin-top:30px;" > Conteneur</button>
      <button class=" button1" id="server"  onclick="myfunction2(this.id)" style="width:102px;" > Serveur</button>
    </div>

    <div class="content">
   
    <div class="box" id="myDiv">
      <div style="float:right;" ><button class="X" onclick="hide()">X</button></div>
      <div id="Progress">
      <script src="js/app.js">
        function hide(){
          var div = document.getElementById("myDiv");
          div.style.display = "none";
        }
      </script>
      </div>
   </div>

      <h1>ADMIN SECTION</h1>
     
      <!-- <button id="buttonContainer" onclick='callApi()' data-id='6a5939a9-0fdb-411d-8be2-e0fc43d65aea' >Click me</button>-->

      <div id="right_side_container" style=" height:80vh;overflow:auto;">
        <table id="display_json_data" class="table" >
          <script>
          window.onload = function() {
            // Call the function from the external file
            myfunction2("container");
          };
          </script></table>
      </div>
      
    </div>
  </div>

  
</body>
</html>




   
