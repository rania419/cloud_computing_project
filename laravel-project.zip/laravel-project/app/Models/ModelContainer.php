<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ModelContainer extends Model
{
    protected $fillable=['nom','image','cpu','memory','command','Entrypoint','env'];
}
