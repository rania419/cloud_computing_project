<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use Illuminate\Support\Facades\Http;
use GuzzleHttp\Client;
use App\Models\ModelForm;
use App\Models\ModelContainer;
use App\Models\server_model;


class StaticController extends Controller{
  
    public function index(){
        return view('create');
        //return "<h1> index <h1>";
    }
    
    public function admin(){
        return view('dashboard');
    }


    //-------------------containerr--------------------------------------
     public function start_container(Request $request){
    
        // Step 1: Authenticate and obtain an authentication token from Keystone
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('http://192.168.58.100:5000/v3/auth/tokens', [
            'auth' => [
                'identity' => [
                    'methods' => ['password'],
                    'password' => [
                        'user' => [
                            'name' => 'admin',
                            'domain' => [
                                'name' => 'Default',
                            ],
                            'password' => 'openstack',
                        ],
                    ],
                ],
                'scope' => [
                    'project' => [
                        'id' => 'a686b3273b3f4fd691c8a90ea6c3d626',
                    ],
                ],
            ],
        ]);

        $token = $response->header('X-Subject-Token');
        
        $id = $request->input('id');
        $zunUrl = 'http://192.168.58.100:9517/v1/containers/'.$id.'/start';
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'X-Auth-Token' => $token,
        ])->post($zunUrl);
        
        return "container started";
        return $response->json();
        
        return 'the token is  <h1> '.$token.'</h1> '; 
    }

    public function delete_container(Request $request){

        
        // Step 1: Authenticate and obtain an authentication token from Keystone
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('http://192.168.58.100:5000/v3/auth/tokens', [
            'auth' => [
                'identity' => [
                    'methods' => ['password'],
                    'password' => [
                        'user' => [
                            'name' => 'admin',
                            'domain' => [
                                'name' => 'Default',
                            ],
                            'password' => 'openstack',
                        ],
                    ],
                ],
                'scope' => [
                    'project' => [
                        'id' => 'a686b3273b3f4fd691c8a90ea6c3d626',
                    ],
                ],
            ],
        ]);

        $token = $response->header('X-Subject-Token');
        
        $id= $request->input('id') ;//hna tjibih mn request taak 

 
        $zunUrlDelete = 'http://192.168.58.100:9517/v1/containers/'.$id.'';
        
        $zunUrlStop =   'http://192.168.58.100:9517/v1/containers/'.$id.'/stop';
        
        //we need to stop it first 
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'X-Auth-Token' => $token,
        ])->post($zunUrlStop);

        //then delete
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'X-Auth-Token' => $token,
        ])->delete($zunUrlDelete);
        
        return ("container deleted");
    }

    public function stop_container(Request $request){
        
        $authUrl = 'http://192.168.58.100:5000/v3/auth/tokens';
        $project = 'a686b3273b3f4fd691c8a90ea6c3d626';
        $username = 'admin';
        $password = 'openstack';

        // Step 1: Authenticate and obtain an authentication token from Keystone
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post($authUrl, [
            'auth' => [
                'identity' => [
                    'methods' => ['password'],
                    'password' => [
                        'user' => [
                            'name' => $username,
                            'domain' => [
                                'name' => 'Default',
                            ],
                            'password' => $password,
                        ],
                    ],
                ],
                'scope' => [
                    'project' => [
                        'id' => $project,
                    ],
                ],
            ],
        ]);

        $val = $request->input('id');
        $token = $response->header('X-Subject-Token');
        $id=$val ;
        
        $zunUrl = 'http://192.168.58.100:9517/v1/containers/'.$id.'/stop';
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'X-Auth-Token' => $token,
        ])->post($zunUrl);
        
     
        return "container stopped";
        
        //return 'the token is  <h1> '.$token.'</h1> '; 
    }

    public function create_container_full(Request $request){
    
        //étape 1 : Authentification et obtention d'un jeton auprès de keystone
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('http://192.168.58.100:5000/v3/auth/tokens', [
            'auth' => [
                'identity' => [
                    'methods' => ['password'],
                    'password' => [
                        'user' => [
                            'name' => 'admin',
                            'domain' => [
                                'name' => 'Default',
                            ],
                            'password' => 'openstack',
                        ],
                    ],
                ],
                'scope' => [
                    'project' => [
                        'id' => 'a686b3273b3f4fd691c8a90ea6c3d626',
                    ],
                ],
            ],
        ]);

        $token = $response->header('X-Subject-Token');

        // Étape 2 : Utiliser le jeton d'authentification pour créer un conteneur avec les paramètres spécifiés
            $zunUrl = 'http://192.168.58.100:9517/v1/containers';

            //Début: récuperer les information introduite dans le formulaire
                $userInput = "";
                $userInput = $request->input('env'); 
                $envArray = explode(',', $userInput); //separer les , 
                $envObject = [];
                foreach ($envArray as $item) {
                    $pair = explode('=', $item); // separer les =
                    if (count($pair) === 2) {
                        $key = trim($pair[0]);
                        $value = trim($pair[1]);
                        $envObject[$key] = $value; // attacher notre valeur a la clé 
                    }
                }
                

                $name =  $request->input('Nom');
                $image =  $request->input('image');
                $cpu = $request->input('cpu');
                $memory = $request->input('memory');
                $entrypoint= $request->input('Entrypoint');
                $command = $request->input('command');
            //Fin
        
            $networkId="dfc887d3-588f-4a8f-a646-92cb9a8e9fe0"; #hadi rayha ttbdl 3la hsab network        
        
            if($envObject == []){
                $response = Http::withHeaders([
                    'Content-Type' => 'application/json',
                    'X-Auth-Token' => $token,
                ])->post($zunUrl, [
                    "image"=> $image,
                    "name"=> $name,
                    "image_driver"=> "docker",
                    "security_groups"=>  ["default"] ,
                    "cpu"=> $cpu,
                    "memory"=>  $memory,
                    "command"=> $command,
                    
                ]);
            }else{
                $response = Http::withHeaders([
                    'Content-Type' => 'application/json',
                    'X-Auth-Token' => $token,
                ])->post($zunUrl, [
                    "image"=> $image,
                    "name"=> $name,
                    "image_driver"=> "docker",
                    "security_groups"=>  ["default"] ,
                    "cpu"=> $cpu,
                    "memory"=>  $memory,
                    "environment"=> $envObject,
                    "command"=> $command,
                ]);
            }
        
       
        return "conteneur creé";
        
    }

    public function list_containers(){

        // Step 1: Authenticate and obtain an authentication token from Keystone
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('http://192.168.58.100:5000/v3/auth/tokens', [
            'auth' => [
                'identity' => [
                    'methods' => ['password'],
                    'password' => [
                        'user' => [
                            'name' => 'admin',
                            'domain' => [
                                'name' => 'Default',
                            ],
                            'password' => 'openstack',
                        ],
                    ],
                ],
                'scope' => [
                    'project' => [
                        'id' => 'a686b3273b3f4fd691c8a90ea6c3d626',
                    ],
                ],
            ],
        ]);

        $token = $response->header('X-Subject-Token');

        $zunUrl = 'http://192.168.58.100:9517/v1/containers';

        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'X-Auth-Token' => $token,
        ])->get($zunUrl);
    
        return $response->json();

        return 'the token is  <h1> '.$token.'</h1> '; 
    }

    public function stat_container(Request $request){
        
        // Step 1: Authenticate and obtain an authentication token from Keystone
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('http://192.168.58.100:5000/v3/auth/tokens', [
            'auth' => [
                'identity' => [
                    'methods' => ['password'],
                    'password' => [
                        'user' => [
                            'name' => 'admin',
                            'domain' => [
                                'name' => 'Default',
                            ],
                            'password' => 'openstack',
                        ],
                    ],
                ],
                'scope' => [
                    'project' => [
                        'id' => 'a686b3273b3f4fd691c8a90ea6c3d626',
                    ],
                ],
            ],
        ]);

        $token = $response->header('X-Subject-Token');
        $id= $request->input('id');
        
        
        $zunUrl = 'http://192.168.58.100:9517/v1/containers/'.$id.'/stats';
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
            'X-Auth-Token' => $token,
        ])->get($zunUrl);

        return $response->json();
        

    }


    //--------------servers------------------------------

    public function reference($img){
        if($img=="Ubuntu18.04"){
            return ('e9c74423-8eb4-40ee-904a-44e432beaa95');
        }else{
            if($img=="vyatta"){
                return('97218d86-b5ff-43ca-a068-c89150511ab7');
            }else{
                if($img=="cirros-image"){
                    return('96a9fad2-1e91-45a1-ad5a-e4d76f3a941f');
                }
            }
        }
    }

    public function get_status_server(){
        $client = new Client();
        $response = $client->request('GET', 'https://192.168.58.100:8774/v2.1/servers/7d081719-ea6b-4dd0-85b7-9c48941ef008', [
            'headers' => [
                'X-Auth-Token' => 'gAAAAABkhF8nwtNmqcIZ7kbv3yGgtwbNoiQsvi0IS-MOr2rmzio1b_EgQYr_fc30QOKjaUpZX7UhsF6dBpbhbftk3KizMMKeNa1lNjvPRKUYKkuzIIbndZlGBzD-mibosyfrjIR5dKDNvYJF34CSxzwyBCiCr3K7_FOLXlfTYTVpQR0tTN5kkBc'
            ]
        ]);

        $status = json_decode($response->getBody(), true)['server']['status'];

        print($status);
    }
    public function list_servers(){
        
        //étape 1 : Authentification et obtention d'un jeton auprès de keystone
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('http://192.168.58.100:5000/v3/auth/tokens', [
            'auth' => [
                'identity' => [
                    'methods' => ['password'],
                    'password' => [
                        'user' => [
                            'name' => 'admin',
                            'domain' => [
                                'name' => 'Default',
                            ],
                            'password' => 'openstack',
                        ],
                    ],
                ],
                'scope' => [
                    'project' => [
                        'id' => 'a686b3273b3f4fd691c8a90ea6c3d626',
                    ],
                ],
            ],
        ]);

        //vérifier
        if ($response->status() === 201) {
            $token = $response->header('X-Subject-Token');

            $computeUrl='http://192.168.58.100:8774/v2.1/servers';
            $response = Http::withHeaders([
                    'Content-Type' => 'application/json',
                    'X-Auth-Token' => $token,
                ])->get($computeUrl);
            
            return $response->json();

        } else {
            // Handle error
            return 'username or password are not the right' ; 
        }
    }

    public function create_server(Request $request){
    
       
        $authUrl = 'http://192.168.58.100:5000/v3/auth/tokens';
        $project = 'a686b3273b3f4fd691c8a90ea6c3d626';
        $username = 'admin';
        $password = 'openstack';

        // Step 1: Authenticate and obtain an authentication token from Keystone
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post($authUrl, [
            'auth' => [
                'identity' => [
                    'methods' => ['password'],
                    'password' => [
                        'user' => [
                            'name' => $username,
                            'domain' => [
                                'name' => 'Default',
                            ],
                            'password' => $password,
                        ],
                    ],
                ],
                'scope' => [
                    'project' => [
                        'id' => $project,
                    ],
                ],
            ],
        ]);

        $name= $request->input('nom');
        $image =  $request->input('image');
       // $imageRef= $this->reference($image);

        switch ($image ) {
            case 'vyatta':
                $imageRef = '97218d86-b5ff-43ca-a068-c89150511ab7';
                break;
            case 'cirros-image':
                $imageRef = '96a9fad2-1e91-45a1-ad5a-e4d76f3a941f';
                break;
            case 'Ubuntu18.04':
                $imageRef = '7f5a76f1-cacf-40d8-88a1-914b1503d7cf';
                break;
            
            default:
                $imageRef = '97218d86-b5ff-43ca-a068-c89150511ab7';
                break;
        }

        $flavor =  $request->input('flavor');
        switch ($flavor) {
            case 'tiny':
                $flavorId = '8707892b-8b9b-4b9d-8135-75e48c6b9004';//cirros 512 1 1
                break;
            case 'small':
                $flavorId = '3990b4d6-55ac-4b6b-8f41-a1f5e4a16ec7';
                break;
            case 'medium':
                $flavorId = 'dbd30c13-9cf3-467c-bff6-b0f1b1c73de7';
                break;
            case 'vyatta':
                $flavorId = 'b13e14dd-001e-4224-bb49-e3bc488fac80'; //512 2 1
                break;
            default:
                $flavorId = 'b13e14dd-001e-4224-bb49-e3bc488fac80';
                break;
        }
       

        //check 
        if ($response->status() === 201) {
            
            $token = $response->header('X-Subject-Token');

            $computeUrl='http://192.168.58.100:8774/v2.1/servers';
        
        
            //*** la partie de creation de server  */
            $response = Http::withHeaders([
                'Content-Type' => 'application/json',
                'X-Auth-Token' => $token,
            ])->post($computeUrl, [
                'server' => [
                    'name' => $name,
                    'imageRef' => $imageRef,
                    'flavorRef' => $flavorId,
                    'networks' => [
                        [
                            'uuid' => 'dfc887d3-588f-4a8f-a646-92cb9a8e9fe0'
                        ]
                    ]
                   
                ]
            ]);
            
            if ($response->status() === 201 || $response->status() === 202 ){
                
                return "Serveur Crée";
            }else{
                
                return 'erreur in the creation of the server';
            }

        } else {
            // Handle error
            return 'username or password are not the right'; 
        }
    }
   
    public function login(Request $request){
        
        $username = $request->input('Nom');
        $password = $request->input('password');
        // Step 1: Authenticate and obtain an authentication token from Keystone
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('http://192.168.58.100:5000/v3/auth/tokens', [
            'auth' => [
                'identity' => [
                    'methods' => ['password'],
                    'password' => [
                        'user' => [
                            'name' => $username,
                            'domain' => [
                                'name' => 'Default',
                            ],
                            'password' => $password,
                        ],
                    ],
                ],
                'scope' => [
                    'project' => [
                        'id' => 'a686b3273b3f4fd691c8a90ea6c3d626',
                    ],
                ],
            ],
        ]);

        
        if ($response->status() === 201) {
            return 'true';            
           
        } else {
            // Handle error
            return 'false'; 
            
          
        }
    }

    public function get_server_info_id(Request $request){

        
        
        
        // Step 1: Authenticate and obtain an authentication token from Keystone
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('http://192.168.58.100:5000/v3/auth/tokens', [
            'auth' => [
                'identity' => [
                    'methods' => ['password'],
                    'password' => [
                        'user' => [
                            'name' => 'admin',
                            'domain' => [
                                'name' => 'Default',
                            ],
                            'password' => 'openstack',
                        ],
                    ],
                ],
                'scope' => [
                    'project' => [
                        'id' => 'a686b3273b3f4fd691c8a90ea6c3d626',
                    ],
                ],
            ],
        ]);

        //recuperer id du serveur
        $id= $request->input('id');
        //verifier
        if ($response->status() === 201) {
            $token = $response->header('X-Subject-Token');
            $computeUrl='http://192.168.58.100:8774/v2.1/servers/'.$id;
            $response = Http::withHeaders([
                'Content-Type' => 'application/json',
                'X-Auth-Token' => $token,
            ])->get($computeUrl);
        
            return $response->json();

        } else {
            // Handle error
            return '<h1>username or password are not the right</h1>' ; 
        }
    }
    
    public function get_link_server(Request $request) {

           
        //étape 1 : Authentification et obtention d'un jeton auprès de keystone
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('http://192.168.58.100:5000/v3/auth/tokens', [
            'auth' => [
                'identity' => [
                    'methods' => ['password'],
                    'password' => [
                        'user' => [
                            'name' => 'admin',
                            'domain' => [
                                'name' => 'Default',
                            ],
                            'password' => 'openstack',
                        ],
                    ],
                ],
                'scope' => [
                    'project' => [
                        'id' => 'a686b3273b3f4fd691c8a90ea6c3d626',
                    ],
                ],
            ],
        ]);
    
        
        //recuperer Id du serveur
        $serverId = $request->input('id');

        // Étape 2 : Utiliser le jeton d'authentification pour récuperer les information du serveur
        if ($response->status() === 201) {
            
            $token = $response->header('X-Subject-Token');
            $computeUrl='http://192.168.58.100:8774/v2.1/servers/' . $serverId . '/action';
    
            
    
            $reponse = Http::withHeaders([
                'Content-Type' => 'application/json',
                'X-Auth-Token' => $token,
            ])->post($computeUrl, [
                'os-getVNCConsole' => [
                    'type' => 'novnc',
                ],
            ]);
            
            return $reponse->json()['console']['url'];
            
        } else {
            // Handle error
            return '<h1>username or password are not the right</h1>' ; 
        }
    
    }

    public function start_server(Request $request){
          
        // Step 1: Authenticate and obtain an authentication token from Keystone
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('http://192.168.58.100:5000/v3/auth/tokens', [
            'auth' => [
                'identity' => [
                    'methods' => ['password'],
                    'password' => [
                        'user' => [
                            'name' => 'admin',
                            'domain' => [
                                'name' => 'Default',
                            ],
                            'password' => 'openstack',
                        ],
                    ],
                ],
                'scope' => [
                    'project' => [
                        'id' => 'a686b3273b3f4fd691c8a90ea6c3d626',
                    ],
                ],
            ],
        ]);
    
        //verifier
        if ($response->status() === 201) {
            $serverId= $request->input('id'); 
            $token = $response->header('X-Subject-Token');
          
            $computeUrl='http://192.168.58.100:8774/v2.1/servers/' . $serverId . '/action';
    
            
            $reponse = Http::withHeaders([
                'Content-Type' => 'application/json',
                'X-Auth-Token' => $token,
            ])->post($computeUrl, [
                'os-start' => null,
            ]);
    
            
            return 'server started';
            
        } else {
            // Handle error
            return '<h1>username or password are not the right</h1>' ; 
        }
    
    }
    
    public function stop_server(Request $request){

        // Step 1: Authenticate and obtain an authentication token from Keystone
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('http://192.168.58.100:5000/v3/auth/tokens', [
            'auth' => [
                'identity' => [
                    'methods' => ['password'],
                    'password' => [
                        'user' => [
                            'name' => 'admin',
                            'domain' => [
                                'name' => 'Default',
                            ],
                            'password' => 'openstack',
                        ],
                    ],
                ],
                'scope' => [
                    'project' => [
                        'id' => 'a686b3273b3f4fd691c8a90ea6c3d626',
                    ],
                ],
            ],
        ]);
        //verifier
        if ($response->status() === 201) {
            $serverId=$request->input('id'); 
            $token = $response->header('X-Subject-Token');
        
            $computeUrl='http://192.168.58.100:8774/v2.1/servers/' . $serverId . '/action';

            $reponse = Http::withHeaders([
                'Content-Type' => 'application/json',
                'X-Auth-Token' => $token,
            ])->post($computeUrl, [
                'os-stop' => null,
            ]);

            
            return 'server stopped';
            
        } else {
            // Handle error
            return '<h1>username or password are not the right</h1>' ; 
        }
    }

    public function delete_server(Request $request){
        
        // Step 1: Authenticate and obtain an authentication token from Keystone
        $response = Http::withHeaders([
            'Content-Type' => 'application/json',
        ])->post('http://192.168.58.100:5000/v3/auth/tokens', [
            'auth' => [
                'identity' => [
                    'methods' => ['password'],
                    'password' => [
                        'user' => [
                            'name' => 'admin',
                            'domain' => [
                                'name' => 'Default',
                            ],
                            'password' => 'openstack',
                        ],
                    ],
                ],
                'scope' => [
                    'project' => [
                        'id' => 'a686b3273b3f4fd691c8a90ea6c3d626',
                    ],
                ],
            ],
        ]);

        //verifier
        if ($response->status() === 201) {
            
            $serverId= $request->input('id'); 
                      
            $token = $response->header('X-Subject-Token');
            
            $computeUrl='http://192.168.58.100:8774/v2.1/servers/' . $serverId.'' ;

           
            $reponse = Http::withHeaders([
                'Content-Type' => 'application/json',
                'X-Auth-Token' => $token,
            ])->delete($computeUrl);

            return 'server deleted';
            
        } else {
            // Handle error
            return '<h1>username or password are not the right</h1>' ; 
        }

    }

   
}


    