
//extract data from website list-containers and save it

fetch('http://127.0.0.1:8000/api/list-servers')
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    return response.blob();
  })
  .then(blob => {
    const reader = new FileReader();
    reader.onload = () => {
      const jsonData = reader.result;
      const link = document.createElement('a');
      link.href = URL.createObjectURL(new Blob([jsonData], { type: 'application/json' }));
      link.download = 'server.json';
      //link.click();

      const jsonData1 = JSON.parse(jsonData);
      
     // displayData(jsonData);
      
     createTableFromJsonData(jsonData1);  
      
   
    };
    reader.readAsText(blob);
  })
  .catch(error => {
    console.error('There was a problem with the fetch operation:', error);
  });
  
  //////

   function displayData(data) {
	  console.log(data.servers);
	  console.log(data);
   // Do something with the data...
 }

 
  function createTableFromJsonData(data){
   //Get the headers from JSON data
   var headers = Object.keys(data.servers[0]);
   console.log(data.servers);
   //Prepare html header
  
   var headerRowHTML='<tr>';
   for(var i=0;i<headers.length;i++){
     
         headerRowHTML+='<th class="th">'+headers[i]+'</th>';
      
       
   }
   //headerRowHTML+='<th class="th">++</th>';
   headerRowHTML+='</tr>';       
   
   //Prepare all the container records as HTML
   var allRecordsHTML='';
   for(var i=0;i<data.servers.length;i++){
    
       //Prepare html row
       allRecordsHTML+='<tr>';
       for(var j=0;j<headers.length;j++){
           var header=headers[j];


           {
            allRecordsHTML+='<td class="td">'+data.servers[i][header]+'</td>';
           }
           
       }
       allRecordsHTML+='<td><button>hello</button></td>';
       allRecordsHTML+='</tr>';

}
 //Append the table header and all records
   var table=document.getElementById("display_json_data");
   table.innerHTML=headerRowHTML + allRecordsHTML;
}
window.onload = createTableFromJsonData();

//function
function myfunction(){
	  var x = document.getElementById("right_side_container");
	  var y = document.getElementById("left_side_server");


	  if(x.style.display == "none"){
	    x.style.display="block";
	    y.style.display="none";
	   

	  }else{
	    x.style.display = "none";
	    y.style.display = "block";
	  }
}



