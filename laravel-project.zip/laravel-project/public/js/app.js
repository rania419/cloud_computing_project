
function myfunction2(id){
if(id=="container"){
  
//extract data from website list-containers and save it

fetch('http://127.0.0.1:8000/api/list-containers')
.then(response => {
if (!response.ok) {
throw new Error('Network response was not ok');
}
return response.blob();
})
.then(blob => {
const reader = new FileReader();
reader.onload = () => {
const jsonData = reader.result;
const link = document.createElement('a');
link.href = URL.createObjectURL(new Blob([jsonData], { type: 'application/json' }));
link.download = 'container.json';
//link.click();

const jsonData1 = JSON.parse(jsonData);

// displayData(jsonData);

createTableFromJsonData(jsonData1);  
};
reader.readAsText(blob);
})
.catch(error => {
console.error('There was a problem with the fetch operation:', error);
});

function createTableFromJsonData(data){
var data=data;
  
//Get the headers from JSON data
var headers = Object.keys(data.containers[0]);

//Prepare html header

var headerRowHTML='<tr>';
for(var i=0;i<headers.length;i++){

if(headers[i]== 'name' || headers[i]== 'image' || headers[i]== 'status'  || headers[i]== 'cpu' || headers[i]== 'memory'||headers[i]== 'addresses'){
  headerRowHTML+='<th class="th">'+headers[i]+'</th>';
  }  
}
headerRowHTML+='<th class="th">-</th>';

headerRowHTML+='</tr>';       

//Prepare all the container records as HTML
var allRecordsHTML='';
for(var i=0;i<data.containers.length;i++){

  //Prepare html row
  allRecordsHTML+='<tr>';
  for(var j=0;j<headers.length;j++){
    var header=headers[j];

    if(header== 'name'|| header== 'image' || header== 'status'|| header== 'cpu' || header== 'memory')
    {        
      
        allRecordsHTML+='<td class="td">'+data.containers[i][header]+'</td>'; 

        
    }else{
      if(header== 'addresses'){
        if (data.containers[i][header]==""){
          allRecordsHTML+='<td class="td">-</td>';
  
        }else{
            allRecordsHTML+='<td class="td">'+data.containers[i]["addresses"]['dfc887d3-588f-4a8f-a646-92cb9a8e9fe0'][0]['addr']+'</td>';
          
                                  
        }
    }
    }

  }    
  allRecordsHTML+='<td class="td">\
                    <div class="dropdown">\
                      <button  class="dropbtn" style="background-color:#75dda0;">button</button>\
                      <div  class="dropdown-content">\
                        <button id="container" onclick="myfunction2(this.id)" style="">refresh</button>\
                        <button onclick="StartContainer(\''+data.containers[i]["uuid"]+'\')">start</button>\
                        <button  onclick="StopContainer(\''+data.containers[i]["uuid"]+'\')">stop</button>\
                        <button  onclick="DeleteContainer(\''+data.containers[i]["uuid"]+'\')">delete</button>\
                      </div>\
                    </div>\
                  </td>';
  

  allRecordsHTML+='<td class="td">\
                    <div class="dropdown" class="status">\
                      <button   id="stat" class="dropbtn"  onclick="StatContainer(\''+data.containers[i]["uuid"]+'\')">Stat</button>\
                    </div>\
                  </td>';
  
  
  '</td> <button class="dropbtn" style="background-color:#75dda0;" onclick="StatContainer(\''+data.containers[i]["uuid"]+'\')">Stat</button></td>'
  allRecordsHTML+='</tr>';
  
}
  //Append the table header and all records
  var table=document.getElementById("display_json_data");
  table.innerHTML=headerRowHTML + allRecordsHTML;
    
}
// window.onload = createTableFromJsonData();
}else{
  if(id=="server"){

  //extract data from website list-servers and save it
  fetch('http://127.0.0.1:8000/api/list-servers')
    .then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      return response.blob();
    })
  .then(blob => {
    const reader = new FileReader();
    reader.onload = () => {
    const jsonData = reader.result;
    const link = document.createElement('a');
    link.href = URL.createObjectURL(new Blob([jsonData], { type: 'application/json' }));
    // link.download = 'server.json';
    //link.click();

    const jsonData1 = JSON.parse(jsonData);
      
    // displayData(jsonData);
      
    createTableFromJsonData1(jsonData1);  
      
  
    };
    reader.readAsText(blob);
  })
  .catch(error => {
    console.error('There was a problem with the fetch operation:', error);
  });

  function createTableFromJsonData1(data){
  
  //Get the headers from JSON data
  var headers = Object.keys(data.servers[0]);
  
  //Prepare html header

  var headerRowHTML='<tr>';
  for(var i=0;i<headers.length;i++){
    
    if(headers[i]== 'name')
    {        
        headerRowHTML+='<th class="th">'+headers[i]+'</th>';
    }else{
      if(headers[i]== 'links'){
        headerRowHTML+='<th class="th">status</th>';
      }
    }
  }
  
  headerRowHTML+='<th class="th">addresses</th>';
  
  headerRowHTML+='<th class="th"></th>';
  headerRowHTML+='<th class="th"></th>';

  headerRowHTML+='</tr>';       

  var table=[];
  
  //Prepare all the container records as HTML
  var allRecordsHTML='';
  for(var i=0;i<data.servers.length;i++){
    var header='name';
    allRecordsHTML+='<tr>';
    for(var j=0;j<2;j++){
      if((header=='name')){
        allRecordsHTML+='<td class="td">'+data.servers[i][header]+'</td>';
        header='id';
      }else{
        if(header=='id'){
          table= status_ip_server(data.servers[i][header])
          allRecordsHTML+='<td class="td">'+table[0]+'</td>';
          header='name';
        }
          
      }
    }
    allRecordsHTML+='<td class="td">'+table[1]+'</td>';

    allRecordsHTML+='<td class="td"><div class="dropdown">\
    <button class="dropbtn" style="background-color:#75dda0;">button</button>\
        <div  class="dropdown-content">\
          <button id="server" onclick="myfunction2(this.id)">refresh</button>\
          <button onclick="StartServer(\''+data.servers[i]["id"]+'\')">start</button>\
          <button onclick="StopServer(\''+data.servers[i]["id"]+'\')">stop</button>\
          <button onclick="DeleteServer(\''+data.servers[i]["id"]+'\')">delete</button>\
        </div>\
    </div></td>';

    allRecordsHTML+='<td class="td"><button style="background-color:#75dda0;" onclick="AccessServer(this.id)" id='+data.servers[i]['id']+' class="dropbtn">Access server</button> </td>';
    allRecordsHTML+='</tr>'; 
  }

  //Append the table header and all records
  var table=document.getElementById("display_json_data");
  table.innerHTML=headerRowHTML + allRecordsHTML;
}
//window.onload = createTableFromJsonData();

}
}

}
function StatContainer(val){

  var data = {
    id: val
  };

  $.ajax({
    url: 'api/stat-container-id',
    type: 'GET',
    data: data,
    success: function(response){
      
      
      const container = response["CONTAINER"];
      const cpu = response["CPU %"];
      const mem_us = response["MEM USAGE(MiB)"];
      const mem_lim= response["MEM LIMIT(MiB)"];
      const mem = response["MEM %"];
    
      progress(container,cpu,mem_us,mem_lim,mem);
      //alert( response["CPU %"] );
    },
    error: function(xhr, status, error){
      //console.error(error);
    }
  });

}

function AccessServer(val){
  var data = {
    id: val
  };

  $.ajax({
    url: 'api/get-link-server',
    type: 'POST',
    data: data,
    success: function(response){
      alert("Clickez sur OK pour copier le lien ci dessous : \n"+response + navigator.clipboard.writeText(response));
    },
    error: function(xhr, status, error){
      console.error(error);
    }
  });
}

function StartServer(val){
    var data = {
      id: val
    };

    $.ajax({
      url: 'api/start-server-id',
      type: 'GET',
      data: data,
      success: function(response){
        alert(response);
        
      },
      error: function(xhr, status, error){
        console.error(error);
      }
    });
  }

  function DeleteServer(val){
  var data = {
    id: val
  };

  $.ajax({
    url: 'api/delete-server-id',
    type: 'GET',
    data: data,
    success: function(response){
      alert(response);
      
    },
    error: function(xhr, status, error){
      console.error(error);
    }
  });
}

function StopServer(val){
  var data = {
    id: val
  };

  $.ajax({
    url: 'api/stop-server-id',
    type: 'GET',
    data: data,
    success: function(response){
      alert(response);
      
    },
    error: function(xhr, status, error){
      console.error(error);
    }
  });
}

function StartContainer(val){
  var data = {
    id: val
  };

  $.ajax({
    url: 'api/start-container-id',
    type: 'POST',
    data: data,
    success: function(response){
      alert(response);
      
    },
    error: function(xhr, status, error){
      console.error(error);
    }
  });


}

function StopContainer(val){
  var data = {
  id: val
  };

  $.ajax({
  url: 'api/stop-container-id',
  type: 'POST',
  data: data,
  success: function(response){
    alert(response);
    
  },
  error: function(xhr, status, error){
    console.error(error);
  }
  });
}

function DeleteContainer(val){
    var data = {
      id: val
    };

    $.ajax({
      url: 'api/delete-container-id',
      type: 'POST',
      data: data,
      success: function(response){
        alert(response);
        
      },
      error: function(xhr, status, error){
        console.error(error);
      }
    });
}

function progress(container,cpu,mem_us,mem_lim,mem) {  

  // Create the main div element with class and id
var mainDiv = document.createElement("div");
mainDiv.classList.add("box");
mainDiv.id = "myDiv";

// Create the div element with style for the button
var buttonDiv = document.createElement("div");
buttonDiv.style.float = "right";

// Create the button element
var button = document.createElement("button");
button.classList.add("X");
button.textContent = "X";
button.onclick = hide; // Assuming hide() is a defined function

// Append the button to the button div
buttonDiv.appendChild(button);

// Create the progress div element
var progressDiv = document.createElement("div");
progressDiv.id = "Progress";

// Append the button div and progress div to the main div
mainDiv.appendChild(buttonDiv);
mainDiv.appendChild(progressDiv);

// Append the main div to the document body
document.body.appendChild(mainDiv);


  var div = document.getElementById("myDiv");

  div.style.display = "block";

  var elem = document.getElementById("Progress");
  elem.innerHTML = "<br>";
  elem.innerHTML += "<strong>CONTAINER: </strong>" + container + "<br><br>";
  elem.innerHTML += "<strong>CPU %: </strong>" + cpu + "<br><br>";
  elem.innerHTML += "<strong>MEM USAGE(MiB): </strong>" + mem_us + "<br><br>";
  elem.innerHTML += "<strong>MEM LIMIT(MiB): </strong>" + mem_lim + "<br><br>";
  elem.innerHTML += "<strong>MEM %: </strong>" + mem + "<br><br>";

  elem.style.height='250px';
  elem.style.background="rgba(0, 0, 0, 0)";
  elem.style.textAlign="left";

    
}
function hide(){
  var div = document.getElementById("myDiv");
  div.style.display = "none";
}

function status_ip_server(val){
var data = {
  id: val
};


var response=[];

$.ajax({
  async: false,
  url: 'api/get_server_info_id',
  type: 'GET',
  data: data,
  success: function(res){
     
    response = [res.server.status , res.server.addresses.external1[0].addr];
   
    return  response;
  },
  
  /*error: function(xhr, status, error){
    console.error(error);
  },*/

},

);
return  response;
}