<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StaticController;



use Illuminate\Support\Facades\Http;
use GuzzleHttp\Client;
use App\Models\ModelForm;
use App\Models\ModelContainer;
use App\Models\server_model;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});
//[UserController::class, 'index']

Route::GET('create-container', [StaticController::class, 'create_container_full'] );

Route::GET('list-containers', [StaticController::class, 'list_containers']  );

Route::get("login", [StaticController::class, 'login'] );

Route::POST('create-container-full', [StaticController::class, 'create_container_full']  
);

Route::post('create-server', [StaticController::class, 'create_server']  );

Route::GET('list-servers', [StaticController::class, 'list_servers']  );

Route::POST('start-container-id', [StaticController::class, 'start_container'] );

Route::POST('stop-container-id', [StaticController::class, 'stop_container'] );

Route::POST('delete-container-id', [StaticController::class, 'delete_container'] );


Route::POST('get-link-server',[StaticController::class, 'get_link_server'] );

Route::GET('start-server-id', [StaticController::class , 'start_server']);

Route::GET('stop-server-id', [StaticController::class , 'stop_server']);

Route::GET('delete-server-id', [StaticController::class, 'delete_server']);

Route::GET('stat-container-id', [StaticController::class , 'stat_container']);

Route::GET('get_status_server', [StaticController::class , 'get_status_server']);

Route::GET('get_server_info_id', [StaticController::class , 'get_server_info_id']);
