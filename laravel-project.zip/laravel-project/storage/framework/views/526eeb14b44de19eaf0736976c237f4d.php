
<html>

<head>
<link rel="stylesheet" href="css/style.css">
<!--<script src="js/app.js"></script>
-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"> </script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
    body{
        display:flex;
        align-items: center;
        justify-content:center;
     
    }
</style>
</head>
    <body>
        <div>
            <div style="width:390px;background-color:#e1e3e6;padding-top:5px;padding-bottom:5px;margin-bottom:8%;">
                <h2 style="text-align:center;">Authentification</h2>
            </div>
                <form id="myForm">
                    <?php echo e(@csrf_field()); ?>   
                    <div class="form1" class="flex-container">

                        <div class="left">
                            <label class="form-label" for="Nom">Nom</label>
                            <input class="form-control"  type="text" name="Nom"></br>

                            <label class="form-label" for="password">Mot de pass</label>
                            <input class="form-control" type="password" name="password" id="myInput">
                        
                            
                            <input type="checkbox"  style="width:30px" onclick="show_hide()">show password<br><br>
                            
                            <input  class="btn btn-success w-10" type="submit" value="Send"> 
                            
                        </div>
                    </div>

                </form>
        </div>
        <script>
            $(document).ready(submit());

            function submit(){
                $('#myForm').submit(function(event) {
                event.preventDefault(); // Prevent form submission

                const formData = $(this).serialize();
                // alert(formData);

                $.ajax({
                url: 'api/login',
                type: 'GET',
                data: formData,
                success: function(response) {
                    // Handle the API response
                    //console.log(typeof(response));
                    
                    
                    if(response=='true'){
                        alert('Authentification reussi!');
                        location.href = '/create';
                    }else{
                        
                        alert('le nom d\'utilisateur ou le mot de passe ne sont pas corrects');
                    }
                },
                error: function(xhr, status, error) {
                    // Handle any errors
                    alert(error);
                }
                });
            });
            }     
            
            function show_hide() {
                var x = document.getElementById("myInput");
                if (x.type === "password") {
                    x.type = "text";
                } else {
                    x.type = "password";
                }
            }

        </script>

    </body>
</html>




   
<?php /**PATH G:\xampp\htdocs\laravel-project\resources\views/login.blade.php ENDPATH**/ ?>