
<html>

<head>
    <link rel="stylesheet" href="css/style.css">
    

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"> </script>


    <style>
        body{
            display:flex;
        }
        .form2{
            width:auto;
            display:center;
            padding-left: 30px;
            padding-right: 30px;
            padding-top: 20px;
            padding-bottom: 20px;
            background-color: #fff;
            width : auto;
            height: auto;
            border-radius: 12px;
        
            box-shadow: 5px 5px  25px #e0e5e9;
            
            margin-left: 300px;
            margin-top: 6%;
        }

        .dropbtn {
            background-color: #fff;
            color: black;
            padding: 6px;
            font-size: 16px;
            
            border-style: solid;
            border-color:#e2e2e2;
            border-radius:6px; 
            width:100%;  
            
            margin-bottom:25px;
        }

        .dropdown {
        position: relative;
        display: block;
        
        }

        .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f1f1f1;
        min-width: 160px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
        }

        .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        width:100%    ;
        }


        .dropdown:hover .dropbtn {background-color: #e2e2e2;}
    </style>

</head>

<body>
    <div class="page">
        <nav class="navbar-vertical">
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link active" href="dashboard">Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="create">Create new</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="login">Logout</a>
                </li>
            
            </ul>
        </nav>  
        <div class="btn1">
             <button class="button1" id="container" style="margin-top:30px;" ><a href="create">conteneur</a> </button>
             <button class="button1" id="server"><a href="server" >serveur</a></button>
        </div>
        
        <div class="cnt">
            
            <form id="myForm">
                
                <div class="form" class="flex-container">
                    <?php echo e(@csrf_field()); ?>   
                    <div class="left">
                        <label class="form-label" for="nom">Nom Server</label>
                        <input class="form-control"  type="text" name="nom"></br>

                        

                        <div class="dropdown" >
                            <label class="form-label" for="image" >image</label>
                            <select class="dropbtn" name="image">
                                <div class="dropdown-content">
                                    <option value="Ubuntu18.04">Ubuntu18.04</option>
                                    <option value="vyatta">vyatta</option>
                                    <option value="cirros-image">cirros-image</option>
                                    
                                </div>
                            </select>
                        </div>
                        
       
                        <div class="dropdown" >
                            <label class="form-label" for="flavor">Stockage</label>
                            <select class="dropbtn" name="flavor">
                                <div class="dropdown-content">
                                    <option value="tiny">Ram:512    Disk:1G    VCPUs:1</option>
                                    <option value="vyatta">Ram:512    Disk:2G    VCPUs:1</option>
                                    <option value="small">Ram:2048    Disk:10G    VCPUs:1</option>
                                    <option value="medium">Ram:4096    Disk:40G    VCPUs:1</option>
                                    
                                </div>
                            </select>
                        </div>                         
                        <input  class="btn btn-success w-10" type="submit" value="Send">
                        
                    </div>   
                </div>

            </form>
        </div>
        <script>
            $(document).ready(submit());

            function submit(){
                $('#myForm').submit(function(event) {
                event.preventDefault(); // Prevent form submission

                const formData = $(this).serialize();
                
                $.ajax({
                url: 'api/create-server',
                type: 'POST',
                data: formData,
                success: function(response) {
                    // Handle the API response
                    //console.log(typeof(response));
                    
                    alert(response);
                },
                error: function(xhr, status, error) {
                    // Handle any errors
                    alert(error)
                    // console.error(error);
                }
                });
            });
            }            
        </script>
    </div>
</body>
</html>




   
<?php /**PATH G:\xampp\htdocs\laravel-project\resources\views/server.blade.php ENDPATH**/ ?>