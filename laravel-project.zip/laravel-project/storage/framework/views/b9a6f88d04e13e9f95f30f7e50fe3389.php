
<html>

<head>
<link rel="stylesheet" href="css/style.css">
<script src="js/app.js"></script>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<script src="https://code.jquery.com/jquery-3.6.0.min.js"> </script>

</head>
    <body>
        <div class="page">
            <nav class="navbar-vertical">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="/dashboard">Dashboard</a>
                    </li>
                    <li class="nav-item">
                    <a class="nav-link" href="create">Create new</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="login">Logout</a>
                    </li>
                    
                </ul>
            </nav>    
         

            <div class="btn1">
             <button class="button1" id="container" style="margin-top:30px;" ><a href="create">conteneur</a> </button>
             <button class="button1" id="server"><a href="server" >serveur</a></button>
            </div>

           
            <div class="cnt">
                <form  id="myForm" >
                    <div class="form" class="flex-container">
                        <?php echo e(@csrf_field()); ?>   
                        <div class="left">
                                <label class="form-label" for="nom">Nom Container</label>
                                <input class="form-control"  type="text" name="Nom"></br>
                                
                                <label class="form-label" for="image">image</label>
                                <input class="form-control"  type="text" name="image" required></br>
                                
                                <label class="form-label" for="cpu">Cpu</label>
                                <input class="form-control" type="number" name="cpu" ></br> 
                                
                                <label class="form-label" for="memory">RAM (Mb)</label>
                                <input class="form-control" type="number"  name="memory" ></br> 

                                    
                        </div>

                        <div class="right">
                            <label class="form-label" for="env">Variable environement</label>
                            <input class="form-control"  type="text" name="env" placeholder="KEY1=VALUE1,KEY2=VALUE2"></br>

                            <label class="form-label" for="Entrypoint">Entrypoint</label>
                            <input class="form-control"  type="text" name="Entrypoint" ></br>

                            <label class="form-label" for="command">Command</label>
                            <input class="form-control"  type="text" name="command"></br>
                            
                            <label></label>
                            <input  class="btn btn-success w-10" type="submit" onclick='submit()' value="Send"> 
                        </div>
                    </div>
                </form>
            </div>
            

            <script>
                $(document).ready(submit());

                function submit(){
                    $('#myForm').submit(function(event) {
                    event.preventDefault(); // Prevent form submission

                    const formData = $(this).serialize();
                   
                    $.ajax({
                    url: 'api/create-container-full',
                    type: 'POST',
                    data: formData,
                    success: function(response) {
                        // Handle the API response
                        //console.log(typeof(response));
                        
                        alert(response);
                    },
                    error: function(xhr, status, error) {
                        // Handle any errors
                        alert(error)
                        // console.error(error);
                    }
                    });
                });
                }            

            </script>
        </div> 
    </body>
</html>




   
<?php /**PATH G:\xampp\htdocs\laravel-project\resources\views/create.blade.php ENDPATH**/ ?>