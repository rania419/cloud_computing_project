
<html>

<head>
<link rel="stylesheet" href="css/style.css">
<!--<script src="js/app.js"></script>
-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

<style>
    
 
</style>
</head>

    <body>
        <form action="/api/list-containers" method="POST">

            <?php echo e(@csrf_field()); ?>   
            <div class="form" class="flex-container">

                <div class="left">
                    <label class="form-label" for="Nom">Nom</label>
                    <input class="form-control"  type="text" name="Nom"></br>

                    <label class="form-label" for="prenom">Prénom</label>
                    <input class="form-control" name="prenom" cols="30" rows="10"></br>

                    <label class="form-label" for="email">email</label>
                    <input class="form-control" type="email" name="email" placeholder="exemple@gmail.com"></br>    
                </div>

                <div class="right">
                    <label class="form-label" for="addressip">Address Ip</label>
                    <input class="form-control" type="text" name="addressip"  placeholder="X.X.X.X"></br>


                    <label class="form-label" for="Nom_Entreprise">Nom Entreprise</label>
                    <input class="form-control" type="text" name="Nom_Entreprise"></br>

                    <label class="form-label" for="password">Mot de pass</label>
                    <input class="form-control" type="password" name="password"></br>
                    
                    <input  class="btn btn-success w-10" type="submit" value="Send">
                
                </div>

            </div>

        </form> 
    
    </body>
</html>




   
<?php /**PATH G:\xampp\htdocs\laravel-project\resources\views/openstack.blade.php ENDPATH**/ ?>